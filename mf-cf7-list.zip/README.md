# mf-cf7-list
Short code to display contact form 7 form submitions
